import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { Observable, firstValueFrom } from "rxjs";
import { take } from "rxjs/operators";
import { Store } from "@ngrx/store";
import { ApiService } from "src/services/api.service";
import {
  increment,
  addMoreStores,
  loadStoresSuccess,
} from "src/services/data.action";

interface AppState {
  count: number;
  location: { latitude: number; longitude: number };
  stores: any;
}

@Component({
  selector: "app-card-list",
  templateUrl: "./card-list.component.html",
  styleUrls: ["./card-list.component.scss"],
})
export class CardListComponent implements OnInit {
  stores$: Observable<any>;
  count$: Observable<number>;
  location: { latitude: number; longitude: number } = {
    latitude: 0,
    longitude: 0,
  };

  stores: any;

  constructor(
    private _api: ApiService,
    private store: Store<AppState>,
    private cdr: ChangeDetectorRef
  ) {
    this.stores$ = this.store.select("stores");
    this.count$ = this.store.select("count");
    this.store.select("location").subscribe((res) => {
      this.location = res;
    });
    this.store.select("stores").subscribe((res: any) => {
      this.stores = res;
      this.cdr.detectChanges();
    });
  }

  ngOnInit() {}

  onIonInfinite = async (event: CustomEvent) => {
    if (event) {
      await this.fetchMoreData();
      (event.target as HTMLIonInfiniteScrollElement).complete();
    }
  };

  async fetchMoreData() {
    const currentCount = await firstValueFrom(this.count$.pipe(take(1)));
    console.log(currentCount);
    this._api.get(
      this.location.latitude,
      this.location.longitude,
      currentCount,
      currentCount + 3,
      (res: any) => {
        this.store.dispatch(increment());
        this.store.dispatch(addMoreStores({ stores: res.response }));
      }
    );
  }
}
