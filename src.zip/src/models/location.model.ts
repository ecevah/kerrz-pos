export interface LocationModel {
  latitude: number;
  longitude: number;
}
