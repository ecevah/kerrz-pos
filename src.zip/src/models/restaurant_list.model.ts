export interface RestaurantListModel {
  latitude: number;
  longitude: number;
  skip: number;
  limit: number;
}
